import React, { Component } from 'react';
import AccordionComp from './AccordionComp';


class App extends Component{
  render(){
    return (
    	<AccordionComp />
    );    
  }
}

export default App;